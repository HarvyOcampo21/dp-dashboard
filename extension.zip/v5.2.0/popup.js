// popup.js — DP Listing Copier v3.2

const editorSelect   = document.getElementById("editor-select");
const saveEditorBtn  = document.getElementById("save-editor-btn");
const editorFeedback = document.getElementById("editor-feedback");
const editorAvatar   = document.getElementById("editor-avatar");
const editorCardName = document.getElementById("editor-card-name");
const editorCardSub  = document.getElementById("editor-card-sub");

const lifestyleCount    = document.getElementById("lifestyle-count");
const logLifestyleBtn   = document.getElementById("log-lifestyle-btn");
const lifestyleFeedback = document.getElementById("lifestyle-feedback");

// ── Load saved values on open ──────────────────────────────────────────────
chrome.storage.sync.get(["editorName"], ({ editorName }) => {
  if (editorName) {
    editorSelect.value = editorName;
    setEditorCard(editorName);
  }
});

// ── Save editor name ───────────────────────────────────────────────────────
saveEditorBtn.addEventListener("click", () => {
  const name = editorSelect.value.trim();
  if (!name) {
    setEditorFeedback("Please enter your name.", "error");
    return;
  }
  chrome.storage.sync.set({ editorName: name }, () => {
    setEditorCard(name);
    setEditorFeedback("✅ Saved as " + name, "ok");
  });
});

function setEditorCard(name) {
  editorAvatar.textContent = name.slice(0, 2).toUpperCase();
  editorAvatar.classList.remove("unset");
  editorCardName.textContent = name;
  editorCardSub.textContent  = 'Logs go to the "' + name + '" tab';
}

function setEditorFeedback(msg, type) {
  editorFeedback.textContent = msg;
  editorFeedback.className   = "feedback " + type;
}

// ── Lifestyle / Profile logger ─────────────────────────────────────────────
logLifestyleBtn.addEventListener("click", async () => {
  const raw   = lifestyleCount.value.trim();
  const count = parseInt(raw, 10);

  if (!raw || isNaN(count) || count < 1) {
    setLifestyleFeedback("❌ Please enter a valid number (1 or more).", "error");
    return;
  }

  const { editorName } = await chrome.storage.sync.get(["editorName"]);
  if (!editorName) {
    setLifestyleFeedback("❌ Save your name first.", "error");
    return;
  }

  logLifestyleBtn.textContent = "Logging…";
  logLifestyleBtn.disabled    = true;
  setLifestyleFeedback("Sending…", "");

  chrome.runtime.sendMessage(
    { type: "LOG_LIFESTYLE", payload: { count } },
    (response) => {
      logLifestyleBtn.textContent = "Log Lifestyle / Profile";
      logLifestyleBtn.disabled    = false;

      if (chrome.runtime.lastError) {
        setLifestyleFeedback("❌ " + chrome.runtime.lastError.message, "error");
        return;
      }

      if (response?.success) {
        lifestyleCount.value = "";
        setLifestyleFeedback("✅ Logged " + count + " edit" + (count > 1 ? "s" : "") + " for " + editorName, "ok");
      } else {
        setLifestyleFeedback("❌ " + (response?.error || "Unknown error"), "error");
      }
    }
  );
});

function setLifestyleFeedback(msg, type) {
  lifestyleFeedback.textContent = msg;
  lifestyleFeedback.className   = "feedback " + type;
}

// ── Connection status check ────────────────────────────────────────────────
const APPS_SCRIPT_URL = 'https://script.google.com/a/macros/drivenproperties.com/s/AKfycbxRnU165B4OZoIyc-sDFrkQB-tePNsb9MBrMWJa7IRZuTWzzITQvxT6ES7eSCVzc6S-/exec';

async function checkConnection() {
  const dot  = document.getElementById('status-dot');
  const text = document.getElementById('status-text');
  if (!dot || !text) return;

  dot.className  = 'status-dot dot-warn';
  text.textContent = 'Checking…';

  try {
    const res = await fetch(APPS_SCRIPT_URL, {
      method:   'POST',
      headers:  { 'Content-Type': 'text/plain' },
      body:     JSON.stringify({ ping: true }),
      redirect: 'follow',
    });

    if (!res.ok) throw new Error('HTTP ' + res.status);
    const json = await res.json();
    if (!json.success && !json.ping) throw new Error('Bad response');

    dot.className    = 'status-dot dot-ok';
    text.textContent = '✅ Connected to Apps Script';

  } catch (err) {
    dot.className    = 'status-dot dot-error';
    text.textContent = '❌ Disconnected — ' + err.message;
  }
}

// Run on popup open
checkConnection();
