// background.js — DP Listing Copier v3
// Handles LOG_TO_SHEET and LOG_LIFESTYLE messages from content/popup scripts

const APPS_SCRIPT_URL = 'https://script.google.com/a/macros/drivenproperties.com/s/AKfycbxRnU165B4OZoIyc-sDFrkQB-tePNsb9MBrMWJa7IRZuTWzzITQvxT6ES7eSCVzc6S-/exec';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "LOG_TO_SHEET") {
    handleLogToSheet(msg.payload)
      .then(sendResponse)
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (msg.type === "LOG_LIFESTYLE") {
    handleLogLifestyle(msg.payload)
      .then(sendResponse)
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
});

async function handleLogToSheet(data) {
  const { editorName } = await chrome.storage.sync.get(["editorName"]);

  if (!editorName) {
    throw new Error("No editor name set. Click the extension icon and enter your name.");
  }

  const now = new Date();
  const dateStr = new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  }).format(now);

  const row = [
    dateStr,
    data.reqNumber || "",
    data.listingRef || "",
    data.listingLink || "",
    data.location || "",
    data.unitPlot || "",
    data.category || "",
    data.beds || "",
    data.furnishing || "",
    data.photographer || "",
    data.listType || "",
    data.status || "",
    data.receivedDate || "",
    data.rejectionReason || "",
    data.subType || "",
    data.notes || "",
  ];

  const response = await fetch(APPS_SCRIPT_URL, {
    method:   "POST",
    headers:  { "Content-Type": "text/plain" },
    body:     JSON.stringify({ row, editorName, reShoot: data.reShoot === true }),
    redirect: "follow",
  });

  if (!response.ok) {
    const body = await response.text().catch(() => "(no body)");
    throw new Error(`HTTP ${response.status}: ${body}`);
  }

  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error("Apps Script returned non-JSON. Check the deployment URL.");
  }

  if (!result.success) {
    if (result.duplicate) {
      return { success: false, duplicate: true, error: result.error };
    }
    throw new Error(result.error || "Apps Script reported failure.");
  }

  return { success: true };
}

// ── Lifestyle / Profile logger ─────────────────────────────────────────────────

async function handleLogLifestyle(data) {
  const { editorName } = await chrome.storage.sync.get(["editorName"]);

  if (!editorName) {
    throw new Error("No editor name set.");
  }

  const response = await fetch(APPS_SCRIPT_URL, {
    method:   "POST",
    headers:  { "Content-Type": "text/plain" },
    body:     JSON.stringify({
      action:     "logLifestyle",
      editorName: editorName,
      lifestyle:  data.lifestyle || 0,
      profile:    data.profile   || 0,
      others:     data.others    || 0,
    }),
    redirect: "follow",
  });

  if (!response.ok) {
    const body = await response.text().catch(() => "(no body)");
    throw new Error(`HTTP ${response.status}: ${body}`);
  }

  let result;
  try {
    result = await response.json();
  } catch {
    throw new Error("Apps Script returned non-JSON.");
  }

  if (!result.success) {
    throw new Error(result.error || "Apps Script reported failure.");
  }

  return { success: true };
}
