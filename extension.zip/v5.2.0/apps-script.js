/**
 * DP Listing Copier — Google Apps Script v3
 */

var SHEET_ID = "1z3zPGAt9au3FC5fAp_Z5F6j-TBOGFw4AwK_TGqoaugQ";

var HEADERS = [
  "Date Uploaded",
  "DP-REQ Number",
  "Listing Reference",
  "Listing Link",
  "Location",
  "Unit / Plot No",
  "Category",
  "Beds",
  "Furnishing",
  "Photographer",
  "List Type",
  "Status",
  "Received Date",
  "Rejection Reason",
  "Agent Request Sub-type",
  "Notes",
];

var LIFESTYLE_HEADERS = ["Date", "Editor", "Count"];

// ── Entry points ──────────────────────────────────────────────────────────────

function doGet(e) {
  var action = (e && e.parameter && e.parameter.action) || "";
  if (action === "getData") return getAllSheetData();
  return jsonResponse({ success: true, ping: true });
}

function doPost(e) {
  try {
    var payload = JSON.parse(e.postData.contents);

    if (payload.ping) return jsonResponse({ success: true, ping: true });
    if (payload.action === "deleteRow") return deleteRowFromSheet(payload);
    if (payload.action === "updateRow") return updateRowInSheet(payload); // ✅ NEW
    if (payload.action === "logLifestyle") return logLifestyle(payload);

    return handleRequest(payload);
  } catch (err) {
    return jsonResponse({
      success: false,
      error: "Parse error: " + err.message,
    });
  }
}

// ── Core handler ──────────────────────────────────────────────────────────────

function handleRequest(payload) {
  try {
    var row = payload.row;
    var editorName = (payload.editorName || "").trim();

    if (!row || !Array.isArray(row))
      return jsonResponse({ success: false, error: "Invalid row data." });
    if (!editorName)
      return jsonResponse({
        success: false,
        error: "No editor name provided.",
      });

    var ss = SpreadsheetApp.openById(SHEET_ID);
    var sheet = getOrCreateEditorTab(ss, editorName);
    sheet.appendRow(row);
    return jsonResponse({ success: true });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message });
  }
}

// ── Get all data ──────────────────────────────────────────────────────────────

function getAllSheetData() {
  try {
    var ss = SpreadsheetApp.openById(SHEET_ID);
    var sheets = ss.getSheets();
    var result = {};

    sheets.forEach(function (sheet) {
      var name = sheet.getName();
      var values = sheet.getDataRange().getValues();

      if (values.length <= 1) {
        result[name] = [];
        return;
      }

      var headers = values[0];
      result[name] = values.slice(1).map(function (row, i) {
        var obj = {};
        obj["_rowIndex"] = i + 2;
        headers.forEach(function (header, j) {
          var cell = row[j];
          obj[String(header)] =
            cell instanceof Date ? cell.toISOString() : cell;
        });
        return obj;
      });
    });

    return jsonResponse({ success: true, data: result });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message });
  }
}

// ── Delete row ────────────────────────────────────────────────────────────────

function deleteRowFromSheet(payload) {
  try {
    var editorName = (payload.editorName || "").trim();
    var rowIndex = parseInt(payload.rowIndex, 10);

    if (!editorName)
      return jsonResponse({
        success: false,
        error: "No editor name provided.",
      });

    var ss = SpreadsheetApp.openById(SHEET_ID);
    var sheet = ss.getSheetByName(editorName);
    if (!sheet)
      return jsonResponse({
        success: false,
        error: 'Editor tab "' + editorName + '" not found.',
      });

    if (rowIndex > 1 && rowIndex <= sheet.getLastRow()) {
      sheet.deleteRow(rowIndex);
      return jsonResponse({ success: true });
    }

    var dpReq = String(payload.dpReqNumber || "").trim();
    var ref = String(payload.listingReference || "").trim();
    var loc = String(payload.location || "").trim();

    var values = sheet.getDataRange().getValues();
    var headers = values[0];
    var colReq = headers.indexOf("DP-REQ Number");
    var colRef = headers.indexOf("Listing Reference");
    var colLoc = headers.indexOf("Location");

    for (var i = 1; i < values.length; i++) {
      var matchReq = !dpReq || String(values[i][colReq] || "").trim() === dpReq;
      var matchRef = !ref || String(values[i][colRef] || "").trim() === ref;
      var matchLoc = !loc || String(values[i][colLoc] || "").trim() === loc;
      if (matchReq && matchRef && matchLoc) {
        sheet.deleteRow(i + 1);
        return jsonResponse({ success: true });
      }
    }

    return jsonResponse({
      success: false,
      error: "Row not found — may already be deleted.",
    });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message });
  }
}

// ── Update row ────────────────────────────────────────────────────────────────

function updateRowInSheet(payload) {
  try {
    var editorName = (payload.editorName || "").trim();
    var rowIndex = parseInt(payload.rowIndex, 10);
    var updates = payload.updates || {};

    if (!editorName)
      return jsonResponse({
        success: false,
        error: "No editor name provided.",
      });

    var ss = SpreadsheetApp.openById(SHEET_ID);
    var sheet = ss.getSheetByName(editorName);
    if (!sheet)
      return jsonResponse({
        success: false,
        error: 'Editor tab "' + editorName + '" not found.',
      });

    if (rowIndex < 2 || rowIndex > sheet.getLastRow()) {
      return jsonResponse({ success: false, error: "Invalid row index." });
    }

    var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];

    headers.forEach(function (header, i) {
      var key = String(header);
      if (updates.hasOwnProperty(key)) {
        sheet.getRange(rowIndex, i + 1).setValue(updates[key]);
      }
    });

    return jsonResponse({ success: true });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message });
  }
}

// ── Lifestyle logger ──────────────────────────────────────────────────────────

function logLifestyle(payload) {
  try {
    var editorName = (payload.editorName || "").trim();
    var count = parseInt(payload.count, 10);

    if (!editorName)
      return jsonResponse({
        success: false,
        error: "No editor name provided.",
      });
    if (isNaN(count) || count < 1)
      return jsonResponse({ success: false, error: "Invalid count." });

    var ss = SpreadsheetApp.openById(SHEET_ID);
    var sheet = ss.getSheetByName("Lifestyle");

    if (!sheet) {
      sheet = ss.insertSheet("Lifestyle");
      sheet.appendRow(LIFESTYLE_HEADERS);
      var hr = sheet.getRange(1, 1, 1, LIFESTYLE_HEADERS.length);
      hr.setFontWeight("bold");
      hr.setBackground("#a855f7");
      hr.setFontColor("#ffffff");
      sheet.setFrozenRows(1);
      sheet.autoResizeColumns(1, LIFESTYLE_HEADERS.length);
    }

    var dateStr = new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(new Date());

    sheet.appendRow([dateStr, editorName, count]);
    return jsonResponse({ success: true });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message });
  }
}

// ── Tab management ────────────────────────────────────────────────────────────

function getOrCreateEditorTab(ss, editorName) {
  var sheet = ss.getSheetByName(editorName);
  if (!sheet) {
    sheet = ss.insertSheet(editorName);
    sheet.appendRow(HEADERS);
    var hr = sheet.getRange(1, 1, 1, HEADERS.length);
    hr.setFontWeight("bold");
    hr.setBackground("#22c55e");
    hr.setFontColor("#ffffff");
    sheet.setFrozenRows(1);
    sheet.autoResizeColumns(1, HEADERS.length);
  }
  return sheet;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function jsonResponse(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(
    ContentService.MimeType.JSON,
  );
}
