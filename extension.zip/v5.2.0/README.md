# DP Listing Copier & Logger v2.0
Chrome Extension — Copy listing info + log to Google Sheets

---

## What's New in v2.0
- **Log to Sheet** button on every request panel
- Logs: Date, DP-REQ #, Listing Ref, Location, Unit/Plot, Category, Beds, Furnishing, Photographer
- Modal lets you set **Status** (Uploaded / Rejected) and **List Type** before logging
- List Type auto-sets to **Photo Request** when a photographer is assigned
- If no photographer → you choose **Brochure** or **Agent Request**
- All original buttons and keyboard shortcuts preserved

---

## Google Sheet Column Layout

| Col | Field            |
|-----|-----------------|
| A   | Date Uploaded   |
| B   | DP-REQ Number   |
| C   | Listing Ref     |
| D   | Location        |
| E   | Unit / Plot No  |
| F   | Category        |
| G   | Beds            |
| H   | Furnishing      |
| I   | Photographer    |
| J   | List Type       |
| K   | Status          |

---

## Setup (One-Time)

### Step 1 — Google Apps Script

1. Open [https://script.google.com](https://script.google.com) and create a **New Project**.
2. Delete the default code and paste the contents of **`apps-script.gs`**.
3. Replace `YOUR_GOOGLE_SHEET_ID_HERE` with your actual Sheet ID.
   - Find it in your sheet URL: `docs.google.com/spreadsheets/d/**SHEET_ID**/edit`
4. Click **Deploy → New deployment**.
   - Type: **Web app**
   - Execute as: **Me**
   - Who has access: **Anyone**
5. Click **Deploy**, authorise the script when prompted.
6. Copy the **Web App URL** (looks like `https://script.google.com/macros/s/…/exec`).

> ⚠️ Every time you edit the Apps Script, create a **New deployment** (not "Manage existing") or your changes won't take effect.

---

### Step 2 — Load the Chrome Extension

1. Open Chrome and go to `chrome://extensions/`.
2. Enable **Developer mode** (top-right toggle).
3. Click **Load unpacked** and select the `dp-listing-copier` folder.
4. The DP icon will appear in your toolbar.

---

### Step 3 — Configure the Extension

1. Click the **DP icon** in your Chrome toolbar.
2. Paste the Apps Script Web App URL into the input field.
3. Click **Save & Test Connection**.
4. You should see ✅ Connected.

---

## Daily Use

Open any listing request panel. You'll see four buttons in the top-right corner:

| Button        | Action                                             |
|---------------|----------------------------------------------------|
| Listing Info  | Copies REQ #, Listing Ref, Location, Unit/Plot     |
| Sub-Location  | Copies just the sub-location                       |
| Search ×3     | Opens DLD, PropertyFinder, and Google in 3 tabs    |
| **Log to Sheet** | **Opens the log modal → logs data to your sheet** |

### Log Modal
- Previews all extracted data
- Select **Status**: Uploaded or Rejected
- Select **List Type**: Auto-set if photographer exists, otherwise pick Brochure or Agent Request
- Click **Log to Sheet** — done!

---

## Keyboard Shortcuts

| Shortcut  | Action             |
|-----------|--------------------|
| `Alt + C` | Copy Listing Info  |
| `Enter`   | Trigger Search     |
| `Escape`  | Close panel        |

---

## Troubleshooting

**"No Apps Script URL configured"**
→ Click the extension icon and paste your Apps Script URL.

**"HTTP 302" or redirect error**
→ Make sure you deployed as a Web App with "Anyone" access and copied the correct `/exec` URL (not `/dev`).

**"Connection failed" in popup**
→ Redeploy the Apps Script as a new deployment and paste the new URL.

**Fields showing "—" in the modal**
→ The page structure may differ slightly. The extension uses multiple fallback strategies but some fields may not be available on all listing types.
