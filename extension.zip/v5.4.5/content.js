(function () {
  "use strict";

  /* =======================
     EXIT BUTTON (Escape)
  ======================= */
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    const closeBtn = document.querySelector(
      "button.button.is-solid.is-button-icon.preview-close-button",
    );
    if (closeBtn) closeBtn.click();
  });

  /* =======================
     SEARCH BUTTON (Enter)
  ======================= */
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Enter") return;
    const enterBtn = document.querySelector(
      "button.button.ml-auto.search__button__HL",
    );
    if (enterBtn) enterBtn.click();
  });

  /* =======================
     KEYBOARD SHORTCUT (Alt+C → Copy Listing Info)
  ======================= */
  document.addEventListener("keydown", function (e) {
    if (e.altKey && e.key === "c") copyListingInfo();
  });

  /* =======================
     PAGE GUARD
  ======================= */
  function isSingleRequestPage() {
    const hashMatch = /^#Request#.+/.test(location.hash);
    const panelOpen = !!document.querySelector("button.preview-close-button");
    return hashMatch || panelOpen;
  }

  /* =======================
     THEME HELPERS
  ======================= */
  function isSiteDarkMode() {
    return (
      document.documentElement.classList.contains("dark") ||
      document.body.classList.contains("dark") ||
      document.querySelector(".theme-toggle input")?.checked === true
    );
  }

  function getReferenceButton() {
    return (
      document.querySelector("button.button.is-outline") ||
      document.querySelector("button.button") ||
      document.querySelector("button")
    );
  }

  function getExactButtonColors() {
    const ref = getReferenceButton();
    const dark = isSiteDarkMode();

    if (!ref) {
      return dark
        ? {
            bg: "#202c33",
            border: "#6b7280",
            text: "#cbd5e1",
            toastBg: "#1e293b",
            toastText: "#e5e7eb",
          }
        : {
            bg: "#ffffff",
            border: "#d1d5db",
            text: "#1f2937",
            toastBg: "#aeecb0",
            toastText: "#1f2937",
          };
    }

    const styles = getComputedStyle(ref);
    return {
      bg: styles.backgroundColor,
      border: styles.borderColor,
      text: styles.color,
      toastBg: dark ? "#1e293b" : "#aeecb0",
      toastText: dark ? "#e5e7eb" : "#1f2937",
    };
  }

  /* =======================
     DATA HELPERS
  ======================= */
  function getScopedContainer() {
    return (
      document.querySelector(".listing-detail, main, #app, .request-detail") ||
      document.body
    );
  }

  // ⚠️ CRITICAL — do NOT modify these regex patterns
  function getExactText(regex) {
    const container = getScopedContainer();
    return (
      [...container.querySelectorAll("span, div")]
        .filter((el) => el.children.length === 0)
        .map((el) => el.textContent.trim())
        .find((text) => regex.test(text)) || ""
    );
  }

  function getAllLocations() {
    const metaBlocks = [...document.querySelectorAll(".meta.is-flex")];
    const locations = [];

    for (const block of metaBlocks) {
      const loc =
        block.dataset.tooltip?.trim() ||
        block.textContent.replace(/\s+/g, " ").trim();

      if (loc && !/Beds|Baths|Furnishing/i.test(loc)) {
        locations.push(loc);
      }

      if (locations.length >= 2) break;
    }

    return locations.join(" | ");
  }

  function getSecondLocationOnly() {
    const el = document.querySelector(
      "div.meta.is-flex.is-align-items-center[data-tooltip] span",
    );
    return el ? el.innerText.trim() : "";
  }

  function getUnitPlotNumber() {
    const container = getScopedContainer();
    const text = (container.innerText || "")
      .replace(/\s+/g, " ")
      .slice(0, 5000);

    const STOP_WORDS =
      "Location|Published|Beds|Baths|Furnishing|Pending|Approved|Scheduled|Hold|Completed|Rejected";

    const patterns = [
      new RegExp(
        `Unit\\s*\\/\\s*Plot\\s*(?:No\\.?\\s*)?[:\\-]?\\s*([^\\n]+?)(?=\\s(?:${STOP_WORDS})|$)`,
        "i",
      ),
      new RegExp(
        `Office\\s*[:\\-]?\\s*([^\\n]+?)(?=\\s(?:${STOP_WORDS})|$)`,
        "i",
      ),
      new RegExp(
        `Unit\\s*(?:No\\.?\\s*)?[:\\-]?\\s*([^\\n]+?)(?=\\s(?:${STOP_WORDS})|$)`,
        "i",
      ),
      new RegExp(
        `Plot\\s*(?:No\\.?\\s*)?[:\\-]?\\s*([^\\n]+?)(?=\\s(?:${STOP_WORDS})|$)`,
        "i",
      ),
    ];

    for (const p of patterns) {
      const m = text.match(p);
      if (m) return m[1].replace(/^No\s+/i, "").trim();
    }

    return "";
  }

  function formatLongDate(dateStr) {
    if (!dateStr) return "";
    const date = new Date(dateStr);
    return new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(date);
  }

  /* =======================
     SIDEBAR FIELD EXTRACTOR
  ======================= */
  function getSidebarValue(labelText) {
    const items = document.querySelectorAll('[data-v-8e28dde2][class*="item"]');
    for (const item of items) {
      const label = item.querySelector("label[data-v-8e28dde2]");
      if (
        label &&
        label.textContent.trim().toLowerCase() === labelText.toLowerCase()
      ) {
        const span = item.querySelector("span[data-v-8e28dde2]");
        if (span)
          return span.getAttribute("data-tooltip") || span.textContent.trim();
      }
    }

    const allItems = document.querySelectorAll('[class*="item"]');
    for (const item of allItems) {
      const labels = item.querySelectorAll("label");
      for (const label of labels) {
        if (
          label.textContent.trim().toLowerCase() === labelText.toLowerCase()
        ) {
          const span = item.querySelector("span");
          if (span)
            return span.getAttribute("data-tooltip") || span.textContent.trim();
        }
      }
    }

    return "";
  }

  /* =======================
     PHOTOGRAPHER EXTRACTOR
  ======================= */
  function getPhotographer() {
    const sel = document.querySelector('select[id*="photographer"]');
    if (sel) {
      const opt = sel.options[sel.selectedIndex];
      const name = opt ? opt.textContent.trim() : "";
      if (name && name !== "—" && name !== "-" && opt.value) return name;
    }

    const container = getScopedContainer();
    const photographerLabels = [
      ...container.querySelectorAll("label, span, p"),
    ].filter(
      (el) =>
        el.children.length === 0 &&
        /^Photographer$/i.test(el.textContent.trim()),
    );

    for (const labelEl of photographerLabels) {
      let parent = labelEl.parentElement;
      for (let i = 0; i < 5; i++) {
        if (!parent) break;
        const candidates = [
          ...parent.querySelectorAll("p, span, strong, b, h5, h6"),
        ].filter(
          (el) =>
            el.children.length === 0 &&
            el.textContent.trim() &&
            !/^Photographer$/i.test(el.textContent.trim()) &&
            !/^Photo(graph)?$/i.test(el.textContent.trim()) &&
            !/^3D\s*Tour$/i.test(el.textContent.trim()) &&
            !/^Request\s*for$/i.test(el.textContent.trim()) &&
            !/^No\s+Photo/i.test(el.textContent.trim()),
        );
        if (candidates.length > 0) return candidates[0].textContent.trim();
        parent = parent.parentElement;
      }
    }

    return "";
  }

  /* =======================
     GATHER ALL DATA
  ======================= */
  function gatherAllData() {
    return {
      reqNumber: getExactText(/^DP-REQ-\d+/), // ⚠️ critical — do not modify
      listingRef: getExactText(/^(DP|CBB|DPA)-(S|R)-\d+/), // ⚠️ critical — do not modify
      listingLink: window.location.href,
      location: getAllLocations(),
      unitPlot: getUnitPlotNumber(),
      category: getSidebarValue("Category"),
      beds: getSidebarValue("Beds"),
      furnishing: getSidebarValue("Furnishing"),
      photographer: getPhotographer(),
    };
  }

  /* =======================
     SEARCH ACTION
  ======================= */
  async function searchWithSubLocation() {
    const location = getSecondLocationOnly();
    if (!location) {
      showToast("⚠️ No sub-location found on this page.", true);
      return;
    }

    const encodedLocation = encodeURIComponent(location);

    try {
      await navigator.clipboard.writeText(location);
    } catch (err) {
      console.warn("[DP Listing Copier] Clipboard write failed:", err);
    }

    const dldUrl = `https://dubailand.gov.ae/en/eservices/real-estate-project-status-landing/real-estate-project-status/#/?search=${encodedLocation}`;
    const pfUrl = `https://www.propertyfinder.ae/en/search?c=1&fu=0&ob=mr&q=${encodedLocation}`;
    const googleUrl = `https://www.google.com/search?q=${encodedLocation}+brochure+pdf`;

    showToast(`🔍 Opening 3 tabs for:\n${location}`);
    window.open(dldUrl, "_blank");
    window.open(pfUrl, "_blank");
    window.open(googleUrl, "_blank");
  }

  /* =======================
     CORE ACTIONS
  ======================= */
  function copyListingInfo() {
    const result = [
      getExactText(/^DP-REQ-\d+/), // ⚠️ critical — do not modify
      getExactText(/^(DP|CBB|DPA)-(S|R)-\d+/), // ⚠️ critical — do not modify
      getAllLocations(),
      getUnitPlotNumber(),
    ]
      .filter(Boolean)
      .join(" | ");

    if (!result) {
      showToast("⚠️ No listing info found on this page.", true);
      return;
    }

    navigator.clipboard
      .writeText(result)
      .then(() => showToast("✅ Copied:\n" + result));
  }

  function copySecondLocation() {
    const text = getSecondLocationOnly();
    if (!text) {
      showToast("⚠️ No sub-location found on this page.", true);
      return;
    }
    navigator.clipboard
      .writeText(text)
      .then(() => showToast("✅ Copied:\n" + text));
  }

  /* =======================
     LOG TO SHEET MODAL
  ======================= */
  function openLogModal() {
    if (document.getElementById("dp-log-modal")) return;
    chrome.storage.sync.get(["editorName"], ({ editorName }) => {
      _buildLogModal(editorName || "");
    });
  }

  function _buildLogModal(editorName) {
    if (document.getElementById("dp-log-modal")) return;

    const data = gatherAllData();
    const dark = isSiteDarkMode();
    const hasPhotographer = !!data.photographer;
    const noEditor = !editorName;

    const modalBg = dark ? "#1e293b" : "#ffffff";
    const modalText = dark ? "#e5e7eb" : "#1f2937";
    const borderCol = dark ? "#334155" : "#e5e7eb";
    const inputBg = dark ? "#0f172a" : "#f9fafb";
    const labelCol = dark ? "#94a3b8" : "#6b7280";
    const accentCol = "#22c55e";

    const overlay = document.createElement("div");
    overlay.id = "dp-log-modal";
    overlay.innerHTML = `
      <div id="dp-log-backdrop" style="
        position:fixed; inset:0; background:rgba(0,0,0,0.6);
        z-index:99999; display:flex; align-items:center; justify-content:center;
        backdrop-filter:blur(4px); font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
      ">
        <div style="
          background:${modalBg}; color:${modalText}; border-radius:14px;
          padding:26px 28px; width:460px; max-width:95vw; max-height:90vh;
          overflow-y:auto; box-shadow:0 24px 64px rgba(0,0,0,0.45);
          border:1px solid ${borderCol};
        ">

          <!-- Header -->
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
            <div>
              <h2 style="margin:0; font-size:15px; font-weight:700; letter-spacing:-.01em;">
                📋 Log to Google Sheet
              </h2>
              <p style="margin:3px 0 0; font-size:11px; color:${noEditor ? "#ef4444" : accentCol}; font-weight:600;">
                ${
                  noEditor
                    ? "⚠️ No editor selected — open the extension popup first"
                    : `Logging as: ${editorName} → tab &quot;${editorName}&quot;`
                }
              </p>
            </div>
            <button id="dp-modal-close" style="
              background:none; border:none; color:${labelCol}; font-size:22px;
              cursor:pointer; padding:0 2px; line-height:1; font-weight:300;
            ">×</button>
          </div>

          <!-- Data preview card -->
          <div style="
            background:${inputBg}; border-radius:9px; padding:14px 16px;
            margin-bottom:18px; border:1px solid ${borderCol};
            font-size:13px; line-height:2;
          ">
            ${modalRow("REQ #", data.reqNumber, labelCol)}
            ${modalRow("Listing Ref", data.listingRef, labelCol)}
            ${modalRow("Location", data.location, labelCol)}
            ${modalRow("Unit / Plot", data.unitPlot, labelCol)}
            ${modalRow("Category", data.category, labelCol)}
            ${modalRow("Beds", data.beds, labelCol)}
            ${modalRow("Furnishing", data.furnishing, labelCol)}
            ${modalRow("Photographer", data.photographer || "—", labelCol)}
          </div>

          <!-- Re-shoot toggle -->
          <div style="margin-bottom:14px;">
            <label style="
              display:block; font-size:11px; font-weight:700; color:${labelCol};
              margin-bottom:8px; text-transform:uppercase; letter-spacing:.07em;
            ">Entry Type</label>
            <div style="display:flex; gap:8px;">
              <label style="
                flex:1; display:flex; align-items:center; gap:8px;
                padding:9px 12px; border-radius:8px; cursor:pointer;
                border:1px solid ${borderCol}; background:${inputBg};
                transition: all .15s;
              " id="dp-normal-label">
                <input type="radio" name="dp-entry-type" id="dp-entry-normal" value="normal" checked
                  style="accent-color:#22c55e; width:15px; height:15px;">
                <span style="font-size:13px; color:${modalText};">Normal Log</span>
              </label>
              <label style="
                flex:1; display:flex; align-items:center; gap:8px;
                padding:9px 12px; border-radius:8px; cursor:pointer;
                border:1px solid ${borderCol}; background:${inputBg};
                transition: all .15s;
              " id="dp-reshoot-label">
                <input type="radio" name="dp-entry-type" id="dp-entry-reshoot" value="reshoot"
                  style="accent-color:#f97316; width:15px; height:15px;">
                <span style="font-size:13px; color:${modalText};">📸 Re-shoot</span>
              </label>
            </div>
            <p id="dp-reshoot-hint" style="margin:6px 0 0; font-size:11px; color:${labelCol}; display:none;">
              Re-shoot bypasses duplicate check and pre-fills Notes with "Re-shoot".
            </p>
          </div>

          <!-- Status -->
          <div style="margin-bottom:14px;">
            <label style="
              display:block; font-size:11px; font-weight:700; color:${labelCol};
              margin-bottom:6px; text-transform:uppercase; letter-spacing:.07em;
            ">Status</label>
            <select id="dp-status-select" style="
              width:100%; padding:9px 12px; border-radius:8px;
              border:1px solid ${borderCol}; background:${inputBg};
              color:${modalText}; font-size:14px; outline:none; cursor:pointer;
            ">
              <option value="Uploaded">Uploaded</option>
              <option value="Pending">Pending</option>
              <option value="Rejected">Rejected</option>
              <option value="No NOC">No NOC</option>
            </select>
          </div>

          <!-- Received Date -->
          <div style="margin-bottom:14px;">
            <label style="
              display:block; font-size:11px; font-weight:700; color:${labelCol};
              margin-bottom:6px; text-transform:uppercase; letter-spacing:.07em;
            ">Received Date</label>
            <input id="dp-received-date" type="date" style="
              width:100%; padding:9px 12px; border-radius:8px;
              border:1px solid ${borderCol}; background:${inputBg};
              color:${modalText}; font-size:14px; outline:none; cursor:pointer;
            ">
          </div>

          <!-- Rejection Reason (shown when Rejected or No NOC) -->
          <div id="dp-rejection-wrapper" style="margin-bottom:14px; display:none;">
            <label style="
              display:block; font-size:11px; font-weight:700; color:${labelCol};
              margin-bottom:6px; text-transform:uppercase; letter-spacing:.07em;
            ">Rejection Reason</label>
            <textarea id="dp-rejection-reason" rows="3" placeholder="Enter reason..."
              style="
                width:100%; padding:9px 12px; border-radius:8px;
                border:1px solid ${borderCol}; background:${inputBg};
                color:${modalText}; font-size:14px; outline:none; resize:vertical;
              "></textarea>
          </div>

          <!-- List Type -->
          <div style="margin-bottom:${hasPhotographer ? "14px" : "10px"};">
            <label style="
              display:block; font-size:11px; font-weight:700; color:${labelCol};
              margin-bottom:6px; text-transform:uppercase; letter-spacing:.07em;
            ">List Type</label>
            <select id="dp-listtype-select" style="
              width:100%; padding:9px 12px; border-radius:8px;
              border:1px solid ${borderCol}; background:${inputBg};
              color:${modalText}; font-size:14px; outline:none;
              ${hasPhotographer ? "opacity:0.5; pointer-events:none;" : "cursor:pointer;"}
            ">
              ${
                hasPhotographer
                  ? `<option value="Photo Request">Photo Request</option>`
                  : `<option value="Brochure">Brochure</option>
                     <option value="Agent Request">Agent Request</option>`
              }
            </select>
            <p style="margin:5px 0 0; font-size:11px; color:${labelCol};">
              ${
                hasPhotographer
                  ? `Auto-set to <strong>Photo Request</strong> — photographer assigned.`
                  : `No photographer — select Brochure or Agent Request.`
              }
            </p>
          </div>

          <!-- Agent Request Sub-type -->
          <div id="dp-subtype-wrapper" style="margin-bottom:14px; display:none;">
            <label style="
              display:block; font-size:11px; font-weight:700; color:${labelCol};
              margin-bottom:6px; text-transform:uppercase; letter-spacing:.07em;
            ">Agent Request Type</label>
            <select id="dp-subtype-select" style="
              width:100%; padding:9px 12px; border-radius:8px;
              border:1px solid ${borderCol}; background:${inputBg};
              color:${modalText}; font-size:14px; outline:none; cursor:pointer;
            ">
              <option value="Use my own photos">Use my own photos</option>
              <option value="Stock photos">Stock photos</option>
              <option value="Similar layout">Similar layout</option>
              <option value="Others">Others</option>
            </select>
          </div>

          <!-- ✅ Notes -->
          <div style="margin-bottom:22px;">
            <label style="
              display:block; font-size:11px; font-weight:700; color:${labelCol};
              margin-bottom:6px; text-transform:uppercase; letter-spacing:.07em;
            ">Notes <span style="font-weight:400;text-transform:none;letter-spacing:0;">(optional)</span></label>
            <textarea id="dp-notes" rows="3" placeholder="Any additional notes about this listing…"
              style="
                width:100%; padding:9px 12px; border-radius:8px;
                border:1px solid ${borderCol}; background:${inputBg};
                color:${modalText}; font-size:14px; outline:none; resize:vertical;
              "></textarea>
          </div>

          <!-- Action buttons -->
          <div style="display:flex; gap:10px;">
            <button id="dp-modal-submit" style="
              flex:1; padding:11px 0; background:${noEditor ? "#64748b" : accentCol}; color:#fff;
              border:none; border-radius:8px; font-size:14px; font-weight:700;
              cursor:${noEditor ? "not-allowed" : "pointer"}; transition:opacity .15s;
              ${noEditor ? "opacity:0.5;" : ""}
            ">✅ Log to Sheet</button>
            <button id="dp-modal-cancel" style="
              padding:11px 18px; background:${inputBg}; color:${modalText};
              border:1px solid ${borderCol}; border-radius:8px; font-size:14px;
              font-weight:600; cursor:pointer; transition:opacity .15s;
            ">Cancel</button>
          </div>

        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    // Set today's date as default
    const today = new Date().toISOString().split("T")[0];
    const dateInput = document.getElementById("dp-received-date");
    if (dateInput) dateInput.value = today;

    // Re-shoot toggle behavior
    const normalRadio = document.getElementById("dp-entry-normal");
    const reshootRadio = document.getElementById("dp-entry-reshoot");
    const reshootHint = document.getElementById("dp-reshoot-hint");
    const reshootLabel = document.getElementById("dp-reshoot-label");
    const normalLabel = document.getElementById("dp-normal-label");
    const notesField = document.getElementById("dp-notes");

    [normalRadio, reshootRadio].forEach((radio) => {
      radio.addEventListener("change", () => {
        const isReshoot = reshootRadio.checked;
        reshootHint.style.display = isReshoot ? "block" : "none";
        reshootLabel.style.borderColor = isReshoot ? "#f97316" : borderCol;
        reshootLabel.style.background = isReshoot
          ? "rgba(249,115,22,.1)"
          : inputBg;
        normalLabel.style.borderColor = isReshoot ? borderCol : "#22c55e";
        normalLabel.style.background = isReshoot
          ? inputBg
          : "rgba(34,197,94,.08)";
        // Pre-fill notes with Re-shoot if empty
        if (isReshoot && notesField && !notesField.value.trim()) {
          notesField.value = "Re-shoot";
        }
        if (!isReshoot && notesField && notesField.value === "Re-shoot") {
          notesField.value = "";
        }
      });
    });

    // Show/hide sub-type dropdown
    const listTypeSelect = document.getElementById("dp-listtype-select");
    const subTypeWrapper = document.getElementById("dp-subtype-wrapper");
    if (listTypeSelect && !hasPhotographer) {
      listTypeSelect.addEventListener("change", () => {
        subTypeWrapper.style.display =
          listTypeSelect.value === "Agent Request" ? "block" : "none";
      });
    }

    // Show/hide rejection reason (Rejected OR No NOC)
    const statusSelect = document.getElementById("dp-status-select");
    const rejectionWrapper = document.getElementById("dp-rejection-wrapper");
    if (statusSelect) {
      statusSelect.addEventListener("change", () => {
        const v = statusSelect.value;
        rejectionWrapper.style.display =
          v === "Rejected" || v === "No NOC" ? "block" : "none";
      });
    }

    // Hover states
    const submitBtn = document.getElementById("dp-modal-submit");
    const cancelBtn = document.getElementById("dp-modal-cancel");
    [submitBtn, cancelBtn].forEach((btn) => {
      btn.addEventListener("mouseenter", () => {
        if (!noEditor) btn.style.opacity = "0.8";
      });
      btn.addEventListener("mouseleave", () => {
        if (!noEditor) btn.style.opacity = "1";
      });
    });

    // Close handlers
    document.getElementById("dp-modal-close").onclick = closeLogModal;
    document.getElementById("dp-modal-cancel").onclick = closeLogModal;
    document.getElementById("dp-log-backdrop").onclick = (e) => {
      if (e.target.id === "dp-log-backdrop") closeLogModal();
    };

    // Submit
    submitBtn.onclick = () => {
      if (noEditor) {
        showToast("⚠️ Select your name in the extension popup first.", true);
        return;
      }

      const status = document.getElementById("dp-status-select").value;
      const listType = document.getElementById("dp-listtype-select").value;
      const rawDate = document.getElementById("dp-received-date").value;
      const receivedDate = formatLongDate(rawDate);
      const notes = document.getElementById("dp-notes").value.trim();
      const reShoot =
        document.getElementById("dp-entry-reshoot")?.checked === true;

      const rejectionReason =
        status === "Rejected" || status === "No NOC"
          ? document.getElementById("dp-rejection-reason").value.trim()
          : "";

      const subType =
        listType === "Agent Request"
          ? document.getElementById("dp-subtype-select").value
          : "";

      submitToSheet({
        ...data,
        status,
        listType,
        subType,
        receivedDate,
        rejectionReason,
        notes,
        reShoot,
      });
    };
  }

  function modalRow(label, value, labelCol) {
    return `
      <div style="display:flex; gap:10px; align-items:baseline;">
        <span style="color:${labelCol}; min-width:95px; flex-shrink:0; font-size:12px;">${label}</span>
        <span style="font-weight:600; word-break:break-word;">${value || "—"}</span>
      </div>`;
  }

  function closeLogModal() {
    document.getElementById("dp-log-modal")?.remove();
  }

  /* =======================
     QUICK LOG
  ======================= */
  function quickLogToSheet() {
    const data = gatherAllData();
    let listType = "";

    if (data.photographer) {
      listType = "Photo Request";
    } else {
      listType = "Brochure";
    }

    if (listType === "Agent Request") {
      showToast(
        "⚠️ Agent Requests require additional details. Use 'Log to Sheet' instead.",
        true,
      );
      return;
    }

    const now = new Date();
    const formattedDate = new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(now);

    const payload = {
      ...data,
      status: "Uploaded",
      listType,
      subType: "",
      receivedDate: formattedDate,
      rejectionReason: "",
      notes: "", // ✅ NEW — empty for quick log
    };

    showToast("📤 Logging in background…");

    chrome.runtime.sendMessage(
      { type: "LOG_TO_SHEET", payload },
      (response) => {
        if (chrome.runtime.lastError) {
          showToast(
            "❌ Extension error: " + chrome.runtime.lastError.message,
            true,
          );
          return;
        }
        if (response?.duplicate) {
          showToast(
            "⚠️ Already logged!\n" +
              (response?.error || "This listing was previously logged."),
            true,
          );
        } else if (response?.success) {
          showToast("✅ Quick log successful!");
        } else {
          showToast("❌ Failed: " + (response?.error || "Unknown error"), true);
        }
      },
    );
  }

  /* =======================
     SUBMIT TO SHEET
  ======================= */
  function submitToSheet(data) {
    closeLogModal();
    showToast("📤 Sending to Google Sheet…");

    chrome.runtime.sendMessage(
      { type: "LOG_TO_SHEET", payload: data },
      (response) => {
        if (chrome.runtime.lastError) {
          showToast(
            "❌ Extension error: " + chrome.runtime.lastError.message,
            true,
          );
          return;
        }
        if (response?.duplicate) {
          showToast(
            "⚠️ Already logged!\n" +
              (response?.error || "This listing was previously logged."),
            true,
          );
        } else if (response?.success) {
          showToast("✅ Logged to Google Sheet!");
        } else {
          showToast("❌ Failed: " + (response?.error || "Unknown error"), true);
        }
      },
    );
  }

  /* =======================
     TOAST
  ======================= */
  function showToast(text, isWarning = false) {
    const colors = getExactButtonColors();
    const dark = isSiteDarkMode();

    const toast = document.createElement("div");
    toast.textContent = text;

    Object.assign(toast.style, {
      position: "fixed",
      bottom: "20px",
      right: "30px",
      background: isWarning ? (dark ? "#3b1f1f" : "#fee2e2") : colors.toastBg,
      color: isWarning ? (dark ? "#fca5a5" : "#991b1b") : colors.toastText,
      padding: "12px 16px",
      borderRadius: "8px",
      fontWeight: "600",
      zIndex: "9999",
      whiteSpace: "pre-line",
      maxWidth: "320px",
      overflow: "hidden",
      textOverflow: "ellipsis",
      boxShadow: dark
        ? "0 6px 20px rgba(0,0,0,.6)"
        : "0 6px 20px rgba(0,0,0,.35)",
      opacity: "0",
      transform: "translateY(12px)",
      transition: "opacity .3s ease-out, transform .3s ease-out",
    });

    document.body.appendChild(toast);
    requestAnimationFrame(() => {
      toast.style.opacity = "1";
      toast.style.transform = "translateY(0)";
    });

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(12px)";
    }, 4500);

    setTimeout(() => toast.remove(), 5000);
  }

  /* =======================
     LISTING STATUS DETECTOR
     Reads the status badge next to the listing reference
     (Offplan Pending, QC Approved, Upload Pending, etc.)
  ======================= */
  function getListingStatus() {
    // Look for known status badge texts near the top of the panel
    const badges = [
      ...document.querySelectorAll(
        '.tag, .badge, [class*="tag"], [class*="badge"], [class*="status"], [class*="label"]',
      ),
    ];

    const knownStatuses = [
      "Offplan Pending",
      "Upload Pending",
      "QC Approved",
      "Offplan Approved",
      "Upload Approved",
    ];

    for (const badge of badges) {
      const text = badge.textContent.trim();
      if (knownStatuses.some((s) => text.toLowerCase() === s.toLowerCase())) {
        return text;
      }
    }

    // Fallback: scan all visible text nodes
    const container = getScopedContainer();
    const allText = [...container.querySelectorAll("span, div, p")]
      .filter((el) => el.children.length === 0)
      .map((el) => el.textContent.trim())
      .find((t) =>
        knownStatuses.some((s) => t.toLowerCase() === s.toLowerCase()),
      );

    return allText || "";
  }

  function getListTypeFromStatus(status) {
    const s = status.toLowerCase();
    if (s.includes("offplan")) return "Brochure";
    if (s.includes("qc")) return "Agent Request";
    if (s.includes("upload")) return "Photo Request";
    return "";
  }

  /* =======================
     COMPLETE BUTTON INTERCEPTOR
     Hooks into the CRM's Complete button and triggers logging automatically
  ======================= */
  var _completeHooked = false;

  function hookCompleteButton() {
    if (_completeHooked) return;

    // Find the Complete button — matches "Complete" text inside a button
    const completeBtn = [...document.querySelectorAll("button")].find(
      (btn) => btn.textContent.trim().toLowerCase() === "complete",
    );

    if (!completeBtn) return;

    _completeHooked = true;

    completeBtn.addEventListener(
      "click",
      function (e) {
        const status = getListingStatus();
        const listType = getListTypeFromStatus(status);

        if (!listType) return;

        // Always copy listing info to clipboard on Complete
        const listingInfo = [
          getExactText(/^DP-REQ-\d+/),
          getExactText(/^(DP|CBB|DPA)-(S|R)-\d+/),
          getAllLocations(),
          getUnitPlotNumber(),
        ]
          .filter(Boolean)
          .join(" | ");

        if (listingInfo) {
          navigator.clipboard.writeText(listingInfo).catch(() => {});
        }

        if (listType === "Agent Request") {
          setTimeout(function () {
            openLogModal();
            showToast(
              "📋 Log to Sheet opened — Agent Request detected.\n📎 Listing info copied!",
              false,
            );
          }, 300);
        } else {
          setTimeout(function () {
            quickLogWithType(listType);
          }, 300);
        }
      },
      true,
    );
  }

  function quickLogWithType(listType) {
    const data = gatherAllData();

    const now = new Date();
    const formattedDate = new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(now);

    const payload = {
      ...data,
      status: "Uploaded",
      listType: listType,
      subType: "",
      receivedDate: formattedDate,
      rejectionReason: "",
      notes: "",
      reShoot: false,
    };

    showToast("📤 Logging as " + listType + "…");

    chrome.runtime.sendMessage(
      { type: "LOG_TO_SHEET", payload },
      (response) => {
        if (chrome.runtime.lastError) {
          showToast(
            "❌ Extension error: " + chrome.runtime.lastError.message,
            true,
          );
          return;
        }
        if (response?.duplicate) {
          showToast(
            "⚠️ Already logged!\n" +
              (response?.error || "This listing was previously logged."),
            true,
          );
        } else if (response?.success) {
          showToast(
            "✅ Auto-logged as " +
              listType +
              " — Uploaded!\n📎 Listing info copied to clipboard!",
          );
        } else {
          showToast("❌ Failed: " + (response?.error || "Unknown error"), true);
        }
      },
    );
  }

  /* =======================
     BUTTONS
  ======================= */
  function createButton(id, text, handler) {
    if (!isSingleRequestPage() || document.getElementById(id)) return;

    let container = document.getElementById("dp-button-container");

    if (!container) {
      // Outer wrapper — holds hamburger + collapsible stack
      const wrapper = document.createElement("div");
      wrapper.id = "dp-button-wrapper";
      Object.assign(wrapper.style, {
        position: "fixed",
        top: "10px",
        right: "20px",
        zIndex: "9997",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-end",
        gap: "0px",
      });

      // Hamburger button
      const hamburger = document.createElement("button");
      hamburger.id = "dp-hamburger";
      hamburger.className = "dp-custom-btn";
      hamburger.title = "Toggle tools";
      hamburger.innerHTML = `
        <span class="dp-ham-line"></span>
        <span class="dp-ham-line"></span>
        <span class="dp-ham-line"></span>`;
      Object.assign(hamburger.style, {
        width: "44px",
        height: "44px",
        padding: "10px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: "5px",
        marginBottom: "8px",
        borderLeft: "4px solid #22c55e",
      });

      // Collapsible button stack
      container = document.createElement("div");
      container.id = "dp-button-container";
      Object.assign(container.style, {
        display: "flex",
        flexDirection: "column",
        gap: "10px",
        overflow: "hidden",
        maxHeight: "0px",
        opacity: "0",
        transition:
          "max-height 0.35s cubic-bezier(0.4,0,0.2,1), opacity 0.25s ease",
        transformOrigin: "top right",
      });

      // Toggle open/close
      let isOpen = false;
      hamburger.addEventListener("click", () => {
        isOpen = !isOpen;
        if (isOpen) {
          container.style.maxHeight = "600px";
          container.style.opacity = "1";
          animateHamburger(hamburger, true);
        } else {
          container.style.maxHeight = "0px";
          container.style.opacity = "0";
          animateHamburger(hamburger, false);
        }
      });

      wrapper.appendChild(hamburger);
      wrapper.appendChild(container);
      document.body.appendChild(wrapper);
    }

    const btn = document.createElement("button");
    btn.id = id;
    btn.textContent = text;
    btn.title = text;
    btn.onclick = handler;
    btn.className = "dp-custom-btn";
    container.appendChild(btn);
  }

  function animateHamburger(hamburger, open) {
    const lines = hamburger.querySelectorAll(".dp-ham-line");
    if (!lines.length) return;
    if (open) {

      lines[0].style.transform = "translateY(7px) rotate(45deg)";
      lines[1].style.opacity = "0";
      lines[1].style.transform = "scaleX(0)";
      lines[2].style.transform = "translateY(-8px) rotate(-45deg)";
    } else {
      // Animate into X
      lines[0].style.transform = "";
      lines[0].style.opacity = "";
      lines[1].style.transform = "";
      lines[1].style.opacity = "";
      lines[2].style.transform = "";
      lines[2].style.opacity = "";
    }
  }

  function insertButtons() {
    createButton("copy-listing-btn", "Listing Info", copyListingInfo);
    createButton("copy-sub-location-btn", "Sub-Loc", copySecondLocation);
    createButton("search-sub-location-btn", "Search", searchWithSubLocation);
    createButton("copy-data-btn", "📋 Copy Data", copyAllData);
    createButton("quick-log-btn", "⚡ Quick Log", quickLogToSheet);
    createButton("no-ref-btn", "📷 No Reference", openNoRefModal);
    createButton("log-to-sheet-btn", "Log to Sheet", openLogModal);
    hookCompleteButton();
  }

  function removeButtons() {
    document.getElementById("dp-button-wrapper")?.remove();
    _completeHooked = false;
  }

  /* =======================
     SPA NAVIGATION WATCHER
  ======================= */
  window.addEventListener("hashchange", () => {
    removeButtons();
    setTimeout(insertButtons, 400);
  });

  setInterval(() => {
    const panelOpen = isSingleRequestPage();
    const buttonsExist = !!document.getElementById("dp-button-wrapper");

    if (panelOpen && !buttonsExist) insertButtons();
    else if (!panelOpen && buttonsExist) removeButtons();
    else if (panelOpen && !_completeHooked) hookCompleteButton();
  }, 600);

  /* =======================
     THEME WATCHER
  ======================= */
  let cachedDarkMode = isSiteDarkMode();

  const themeObserver = new MutationObserver(() => {
    const nowDark = isSiteDarkMode();
    if (nowDark !== cachedDarkMode) {
      cachedDarkMode = nowDark;
      removeButtons();
      setTimeout(insertButtons, 100);
    }
  });

  themeObserver.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ["class"],
  });

  /* =======================
     COPY DATA (for Dashboard Edit Modal paste)
  ======================= */
  function copyAllData() {
    const data = gatherAllData();

    // Only the fields needed by the Edit modal paste function
    const payload = {
      __dp_edit_paste__: true, // marker so dashboard knows it's valid
      "DP-REQ Number": data.reqNumber || "",
      "Listing Reference": data.listingRef || "",
      "Listing Link": data.listingLink || "",
      Location: data.location || "",
      "Unit / Plot No": data.unitPlot || "",
      Category: data.category || "",
      Beds: data.beds || "",
      Furnishing: data.furnishing || "",
      "List Type": data.photographer ? "Photo Request" : "",
    };

    const json = JSON.stringify(payload);

    navigator.clipboard
      .writeText(json)
      .then(() =>
        showToast(
          "✅ Data copied! Open the Edit modal on dashboard and click Paste.",
        ),
      )
      .catch(() => showToast("❌ Clipboard write failed.", true));
  }

  /* =======================
     NO REFERENCE MODAL
  ======================= */
  function openNoRefModal() {
    if (document.getElementById("dp-no-ref-modal")) return;
    chrome.storage.sync.get(["editorName"], ({ editorName }) => {
      _buildNoRefModal(editorName || "");
    });
  }

  function _buildNoRefModal(editorName) {
    if (document.getElementById("dp-no-ref-modal")) return;

    const dark = isSiteDarkMode();
    const noEditor = !editorName;
    const modalBg = dark ? "#1e293b" : "#ffffff";
    const modalText = dark ? "#e5e7eb" : "#1f2937";
    const borderCol = dark ? "#334155" : "#e5e7eb";
    const inputBg = dark ? "#0f172a" : "#f9fafb";
    const labelCol = dark ? "#94a3b8" : "#6b7280";
    const accentCol = "#f97316";

    const inputStyle = `
      width:100%; padding:9px 12px; border-radius:8px;
      border:1px solid ${borderCol}; background:${inputBg};
      color:${modalText}; font-size:14px; outline:none;
    `;

    const overlay = document.createElement("div");
    overlay.id = "dp-no-ref-modal";
    overlay.innerHTML = `
      <div id="dp-no-ref-backdrop" style="
        position:fixed; inset:0; background:rgba(0,0,0,0.6);
        z-index:99999; display:flex; align-items:center; justify-content:center;
        backdrop-filter:blur(4px); font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
      ">
        <div style="
          background:${modalBg}; color:${modalText}; border-radius:14px;
          padding:26px 28px; width:420px; max-width:95vw; max-height:90vh;
          overflow-y:auto; box-shadow:0 24px 64px rgba(0,0,0,0.45);
          border:1px solid ${borderCol};
        ">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
            <div>
              <h2 style="margin:0; font-size:15px; font-weight:700;">📷 No Reference Entry</h2>
              <p style="margin:4px 0 0; font-size:11px; color:${accentCol}; font-weight:600;">
                Status → <strong>No Reference</strong>
                ${noEditor ? " · ⚠️ No editor selected" : " · Logging as: " + editorName}
              </p>
            </div>
            <button id="dp-no-ref-close" style="background:none;border:none;color:${labelCol};font-size:22px;cursor:pointer;line-height:1;">×</button>
          </div>

          <div style="
            background:${inputBg}; border:1px solid ${borderCol}; border-left:3px solid ${accentCol};
            border-radius:8px; padding:10px 14px; margin-bottom:18px;
            font-size:11px; color:${labelCol}; line-height:1.6;
          ">
            Use this for photos received without a listing request — VIP agents, advance bookings, or any shoot without a system reference.
          </div>

          <div style="margin-bottom:14px;">
            <label style="display:block;font-size:11px;font-weight:700;color:${labelCol};margin-bottom:6px;text-transform:uppercase;letter-spacing:.07em;">Location</label>
            <input id="dp-no-ref-location" type="text" placeholder="e.g. Jumeirah Lake Towers, Al Fattan…" style="${inputStyle}">
          </div>

          <div style="margin-bottom:14px;">
            <label style="display:block;font-size:11px;font-weight:700;color:${labelCol};margin-bottom:6px;text-transform:uppercase;letter-spacing:.07em;">Photographer</label>
            <input id="dp-no-ref-photographer" type="text" placeholder="Photographer name" style="${inputStyle}">
          </div>

          <div style="margin-bottom:22px;">
            <label style="display:block;font-size:11px;font-weight:700;color:${labelCol};margin-bottom:6px;text-transform:uppercase;letter-spacing:.07em;">Notes <span style="font-weight:400;text-transform:none;">(optional)</span></label>
            <textarea id="dp-no-ref-notes" rows="3" placeholder="Any additional context…" style="${inputStyle} resize:vertical;"></textarea>
          </div>

          <div style="display:flex;gap:10px;">
            <button id="dp-no-ref-submit" style="
              flex:1; padding:11px 0; background:${noEditor ? "#64748b" : accentCol}; color:#fff;
              border:none; border-radius:8px; font-size:14px; font-weight:700;
              cursor:${noEditor ? "not-allowed" : "pointer"};
              ${noEditor ? "opacity:0.5;" : ""}
            ">📷 Log No Reference</button>
            <button id="dp-no-ref-cancel" style="
              padding:11px 18px; background:${inputBg}; color:${modalText};
              border:1px solid ${borderCol}; border-radius:8px; font-size:14px;
              font-weight:600; cursor:pointer;
            ">Cancel</button>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    document.getElementById("dp-no-ref-close").onclick = closeNoRefModal;
    document.getElementById("dp-no-ref-cancel").onclick = closeNoRefModal;
    document.getElementById("dp-no-ref-backdrop").onclick = (e) => {
      if (e.target.id === "dp-no-ref-backdrop") closeNoRefModal();
    };

    document.getElementById("dp-no-ref-submit").onclick = () => {
      if (noEditor) {
        showToast("⚠️ Select your name in the extension popup first.", true);
        return;
      }

      const location = document
        .getElementById("dp-no-ref-location")
        .value.trim();
      const photographer = document
        .getElementById("dp-no-ref-photographer")
        .value.trim();
      const notes = document.getElementById("dp-no-ref-notes").value.trim();

      if (!location && !photographer) {
        showToast("⚠️ Please enter at least a location or photographer.", true);
        return;
      }

      const now = new Date();
      const receivedDate = new Intl.DateTimeFormat("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      }).format(now);

      const data = {
        reqNumber: "",
        listingRef: "",
        listingLink: "",
        location: location,
        unitPlot: "",
        category: "",
        beds: "",
        furnishing: "",
        photographer: photographer,
        listType: "",
        status: "No Reference",
        receivedDate: receivedDate,
        rejectionReason: "",
        subType: "",
        notes: notes,
      };

      closeNoRefModal();
      submitToSheet(data);
    };
  }

  function closeNoRefModal() {
    document.getElementById("dp-no-ref-modal")?.remove();
  }

  /* =======================
     INIT
  ======================= */
  setTimeout(insertButtons, 800);
})();
